//
//  MusicPlayerMVVMApp.swift
//  MusicPlayerMVVM
//
//  Created by macuser on 2023-09-27.
//

import SwiftUI

@main
struct MusicPlayerMVVMApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
